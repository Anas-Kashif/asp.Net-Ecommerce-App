namespace EcommerceApplication.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("ADMIN")]
    public partial class ADMIN
    {
        [Key]
        public int admin_id { get; set; }

        [Required]
        [StringLength(100)]
        public string admin_name { get; set; }

        [Required]
        [StringLength(100)]
        public string admin_email { get; set; }

        [Required]
        [StringLength(100)]
        public string admin_password { get; set; }

        [StringLength(20)]
        public string admin_contact { get; set; }

        [StringLength(255)]
        public string admin_address { get; set; }
    }
}
