using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace EcommerceApplication.Models
{
    public partial class Model1 : DbContext
    {
        public Model1()
            : base("name=Model1")
        {
        }

        public virtual DbSet<ADMIN> ADMINs { get; set; }
        public virtual DbSet<CATEGORY> CATEGORies { get; set; }
        public virtual DbSet<PRODUCT> PRODUCTs { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ADMIN>()
                .Property(e => e.admin_name)
                .IsUnicode(false);

            modelBuilder.Entity<ADMIN>()
                .Property(e => e.admin_email)
                .IsUnicode(false);

            modelBuilder.Entity<ADMIN>()
                .Property(e => e.admin_password)
                .IsUnicode(false);

            modelBuilder.Entity<ADMIN>()
                .Property(e => e.admin_contact)
                .IsUnicode(false);

            modelBuilder.Entity<ADMIN>()
                .Property(e => e.admin_address)
                .IsUnicode(false);

            modelBuilder.Entity<CATEGORY>()
                .Property(e => e.category_name)
                .IsUnicode(false);

            modelBuilder.Entity<CATEGORY>()
                .HasMany(e => e.PRODUCTs)
                .WithOptional(e => e.CATEGORY)
                .HasForeignKey(e => e.product_foreignID)
                .WillCascadeOnDelete();

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.product_name)
                .IsUnicode(false);

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.product_desc)
                .IsUnicode(false);

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.product_sale_price)
                .HasPrecision(10, 2);

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.product_purchase_price)
                .HasPrecision(10, 2);

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.product_picture)
                .IsUnicode(false);
        }
    }
}