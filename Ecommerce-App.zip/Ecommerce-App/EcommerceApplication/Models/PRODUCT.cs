namespace EcommerceApplication.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Web;

    [Table("PRODUCT")]
    public partial class PRODUCT
    {
        [Key]
        public int product_id { get; set; }

        [NotMapped]
        public int Qty { get; set; }


        [Required]
        [StringLength(100)]
        public string product_name { get; set; }

        [Required]
        [StringLength(100)]
        public string product_desc { get; set; }

        public decimal product_sale_price { get; set; }

        public decimal product_purchase_price { get; set; }

        [StringLength(255)]
        public string product_picture { get; set; }

        [NotMapped]
        public HttpPostedFileBase Pic { get; set; }

        public int? product_foreignID { get; set; }

        public virtual CATEGORY CATEGORY { get; set; }
    }
}
