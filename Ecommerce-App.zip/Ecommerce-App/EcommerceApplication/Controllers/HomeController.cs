﻿using EcommerceApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EcommerceApplication.Controllers
{
    public class HomeController : Controller
    {
        Model1 db = new Model1();

        public ActionResult IndexUser()
        {
            return View();
        }

        public ActionResult IndexAdmin()
        {
            return View();
        }

        public ActionResult babarazam()
        {
            return View();
        }

        public ActionResult LoginModule()
        {
            return View();
        }

        [HttpPost]
        public ActionResult LoginModule(ADMIN admin)
        {
            int checkCredentials = db.ADMINs.Where(x => x.admin_email == admin.admin_email && x.admin_password == admin.admin_password).Count();
            if (checkCredentials == 1)
            {
                return RedirectToAction("IndexAdmin", "Home");
            }
            else
            {
                ViewBag.Message = "Invalid Credentials!";
                return View();
            }
        }

        public ActionResult ForgetPassword()
        {
            return View();
        }

        // POST: ForgetPassword - Step 1: Verify Email
        [HttpPost]
        public ActionResult ForgetPassword(string admin_email, string new_password = null)
        {
            if (string.IsNullOrEmpty(new_password))
            {
                // User submitted the email to verify
                bool emailExists = db.ADMINs.Any(x => x.admin_email == admin_email);

                if (emailExists)
                {
                    // Show password reset input field
                    ViewBag.EmailVerified = true;
                    ViewBag.AdminEmail = admin_email;
                    return View();
                }
                else
                {
                    ViewBag.Message = "Email not found!";
                    return View();
                }
            }
            else
            {
                // User submitted the new password - update it now
                var adminUser = db.ADMINs.FirstOrDefault(x => x.admin_email == admin_email);
                if (adminUser != null)
                {
                    adminUser.admin_password = new_password;  // Ideally, hash this before saving in real apps
                    db.SaveChanges();

                    ViewBag.Message = "Password updated successfully!";
                    return RedirectToAction("LoginModule", "Home");
                }
                else
                {
                    ViewBag.Message = "Error: Email not found!";
                    return View();
                }
            }
        }

        public ActionResult shop()
        {
            shopmodel s = new shopmodel();

            s.cat = db.CATEGORies.ToList();
            s.pro = db.PRODUCTs.ToList();

            return View(s);
        }

        public ActionResult Cart()
        {
            return View();
        }

        public ActionResult addcart(int id)
        {
            List<PRODUCT> lst;
            if (Session["mycart"] == null)
            {
                lst = new List<PRODUCT>();
            }
            else
            {
                lst = (List<PRODUCT>)Session["mycart"];
            }
            lst.Add(db.PRODUCTs.Where(p => p.product_id == id).FirstOrDefault());
            lst[lst.Count - 1].Qty = 1;
            Session["mycart"] = lst;


            return RedirectToAction("Cart");
        }

        public ActionResult minus(int rn)
        {
            List<PRODUCT> lst = (List<PRODUCT>)Session["mycart"];

            lst[rn].Qty--;
            Session["mycart"] = lst;


            return RedirectToAction("Cart");
        }

        public ActionResult plus(int rn)
        {
            List<PRODUCT> lst = (List<PRODUCT>)Session["mycart"];

            lst[rn].Qty++;
            Session["mycart"] = lst;


            return RedirectToAction("Cart");
        }

        public ActionResult remove(int rn)
        {
            List<PRODUCT> lst = (List<PRODUCT>)Session["mycart"];

            lst.RemoveAt(rn);
            Session["mycart"] = lst;


            return RedirectToAction("Cart");
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}