﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using EcommerceApplication.Models;

namespace EcommerceApplication.Controllers
{
    public class PRODUCTsController : Controller
    {
        private Model1 db = new Model1();

        // GET: PRODUCTs
        public ActionResult Index()
        {
            var pRODUCTs = db.PRODUCTs.Include(p => p.CATEGORY);
            return View(pRODUCTs.ToList());
        }

        // GET: PRODUCTs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PRODUCT pRODUCT = db.PRODUCTs.Find(id);
            if (pRODUCT == null)
            {
                return HttpNotFound();
            }
            return View(pRODUCT);
        }

        // GET: PRODUCTs/Create
        public ActionResult Create()
        {
            ViewBag.product_foreignID = new SelectList(db.CATEGORies, "category_id", "category_name");
            return View();
        }

        // POST: PRODUCTs/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(PRODUCT pRODUCT)
        {
            if (ModelState.IsValid)
            {
                pRODUCT.Pic.SaveAs(Server.MapPath("~/Pictures/" + pRODUCT.Pic.FileName));
                pRODUCT.product_picture = "~/Pictures/" + pRODUCT.Pic.FileName;
                db.PRODUCTs.Add(pRODUCT);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.product_foreignID = new SelectList(db.CATEGORies, "category_id", "category_name", pRODUCT.product_foreignID);
            return View(pRODUCT);
        }

        // GET: PRODUCTs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PRODUCT pRODUCT = db.PRODUCTs.Find(id);
            if (pRODUCT == null)
            {
                return HttpNotFound();
            }
            ViewBag.product_foreignID = new SelectList(db.CATEGORies, "category_id", "category_name", pRODUCT.product_foreignID);
            return View(pRODUCT);
        }

        // POST: PRODUCTs/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(PRODUCT pRODUCT)
        {
            if (ModelState.IsValid)
            {
                // Get existing product from DB
                var existingProduct = db.PRODUCTs.AsNoTracking().FirstOrDefault(p => p.product_id == pRODUCT.product_id);

                // Check if a new image is uploaded
                if (pRODUCT.Pic != null)
                {
                    string filePath = Server.MapPath("~/Pictures/" + pRODUCT.Pic.FileName);
                    pRODUCT.Pic.SaveAs(filePath);
                    pRODUCT.product_picture = "~/Pictures/" + pRODUCT.Pic.FileName;
                }
                else
                {
                    // Keep old picture if no new file uploaded
                    pRODUCT.product_picture = existingProduct.product_picture;
                }

                db.Entry(pRODUCT).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.product_foreignID = new SelectList(db.CATEGORies, "category_id", "category_name", pRODUCT.product_foreignID);
            return View(pRODUCT);
        }


        // GET: PRODUCTs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            PRODUCT pRODUCT = db.PRODUCTs.Find(id);
            if (pRODUCT == null)
            {
                return HttpNotFound();
            }
            return View(pRODUCT);
        }

        // POST: PRODUCTs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            PRODUCT pRODUCT = db.PRODUCTs.Find(id);
            db.PRODUCTs.Remove(pRODUCT);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
